Nomes: Rodrigo Rosatti Galvão       RA: 176939
       Luis Fernando P. C. Filho    RA: 173166


Obs: O arquivo principal é o estrutura.html. Elem contém os links para acessar os outros arquivos: topicos.html e footer.html.
